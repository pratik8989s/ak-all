package com.beans;

public class InvalidProcessorException extends Exception {

  

    public InvalidProcessorException(String string) {
	System.out.println(string);
    }

}
