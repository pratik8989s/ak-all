package com.beans;

public class newInvalidBrandException extends Exception {

    public newInvalidBrandException(String string) {
	System.out.println(string);
    }

}
