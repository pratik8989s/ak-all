package com.beans;

public class InvalidIDException extends Exception {

    public InvalidIDException(String string) {
	System.out.println(string);
}

  

}
