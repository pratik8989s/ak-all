package collections;

import java.util.Vector;

public class VectorDemo {
	public static void main(String[] args) {
		
		Vector<Integer> v= new Vector<Integer>();
		v.add(10);
		v.add(11);
		v.add(12);
		v.add(13);
		
	}
}
