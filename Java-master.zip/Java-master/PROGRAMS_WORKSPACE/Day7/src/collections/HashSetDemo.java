package collections;

import java.util.HashSet;

public class HashSetDemo {

	public static void main(String[] args) {
		HashSet hs= new HashSet();
		hs.add(2);
		hs.add("asgasdgv");
		hs.add(1.2f);
		System.out.println(hs);//unordered data 
	}
}
