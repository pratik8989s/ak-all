package collections;

import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		TreeSet t= new TreeSet();
		t.add(235234);
		t.add("askljfghsjld");
		t.add(342566);
		t.add(1.f);
		System.out.println(t);
	}
}
