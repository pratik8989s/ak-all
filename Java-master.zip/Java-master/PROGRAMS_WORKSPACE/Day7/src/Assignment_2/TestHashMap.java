package Assignment_2;

public class TestHashMap {

	public static void main(String[] args) {
		Employee s= new Employee();
		s.setNames(1, "akash");
		s.setNames(2, "asafg");
		s.setNames(4, "sfsaf");
		s.setNames(3, "aafsheh");
	/*	s.printNames();
		s.getName(1);
		s.printSize();*/
		s.printNamesKeySet();
		/*s.remove(3);
		s.printNames();*/
	}
}
