package Assignment4;

public class TestStudent {

	public static void main(String[] args) {
		Student s1= new Student(1,"akash");
		Student s2= new Student(2,"akasha");
		Student s3= new Student(3,"akash");
		s1.compareTo(s2.getName());
	}
}
