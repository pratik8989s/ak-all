package Assignment4;

import java.util.ArrayList;

public class StudentSortDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Student> als=new ArrayList<Student>();
		als.add(new Student(1, "akash"));
		als.add(new Student(2, "zhakas"));
		als.add(new Student(4, "kash"));
		als.add(new Student(3, "akshay"));
		als.add(new Student(5, "ash"));
	
		System.out.println(als);
		
		als.
		
	}

}
