package Assignments;

public class Program2 
{
	public static void main(String[] args) 
	{
		
	}
}
