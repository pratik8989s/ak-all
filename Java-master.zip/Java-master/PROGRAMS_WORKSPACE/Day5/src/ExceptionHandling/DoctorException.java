package ExceptionHandling;

public class DoctorException extends Exception {

	  public DoctorException(String msg) {
		  super(msg);
		// TODO Auto-generated constructor stub
		/*  System.out.println("in default constructor");*/
	}
	
}
