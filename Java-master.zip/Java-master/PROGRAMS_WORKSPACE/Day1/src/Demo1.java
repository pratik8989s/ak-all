
public class Demo1 
{
	public static void main(String[] args) 
	{
	
		/*int[] arr = {1,2,3,4,5,6,7};
		
		for (int i = 0; i < arr.length; i++) 
		{
		System.out.println(arr[i]);	
		}*/
		
		
		int n1=Integer.parseInt(args[0]);
		int n2=Integer.parseInt(args[1]);
		
		int sum=n1+n2;
		System.out.println("sum is:"+sum);
		System.out.println("no of args:"+args.length);
		
	}
}
