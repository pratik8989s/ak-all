package Assignment;

public class Storage extends Thread {
	private int count;
	//Printer p;

	/*@Override
	public void run() {
		// TODO Auto-generated method stub
		p.start();
	}
	 */
	 public int getCount() {
		return count;
	}

	 public void setCount(int count) {
		this.count = count;

	}


}
