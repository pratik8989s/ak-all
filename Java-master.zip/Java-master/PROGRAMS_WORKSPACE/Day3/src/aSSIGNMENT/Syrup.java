package aSSIGNMENT;

public class Syrup extends Medicine{

	@Override
	public void displayLabel() {
		// TODO Auto-generated method stub
		System.out.println("Syrup should be handled with care");
	}

}
