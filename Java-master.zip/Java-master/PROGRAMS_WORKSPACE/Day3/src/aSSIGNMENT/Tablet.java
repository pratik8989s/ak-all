package aSSIGNMENT;

public class Tablet extends Medicine {

	@Override
	public void displayLabel() {
		// TODO Auto-generated method stub
		System.out.println("Tablet is stored in a cool dry place");
	}

}
