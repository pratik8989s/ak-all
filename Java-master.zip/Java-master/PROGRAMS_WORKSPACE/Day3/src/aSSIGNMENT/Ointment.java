package aSSIGNMENT;

public class Ointment extends Medicine {

	@Override
	public void displayLabel() {
		// TODO Auto-generated method stub
		System.out.println("Ointment for external use only");
	}
	
}
