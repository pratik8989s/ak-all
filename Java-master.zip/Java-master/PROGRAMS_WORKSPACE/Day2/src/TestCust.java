
public class TestCust {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer c1= new Customer("C01","akash",1234);
		Customer c2= new Customer("C02","zkash",9765);
		Customer c3= new Customer("C03","sh",872);
		Customer c4= new Customer("C04","ash",4835);
		
		Customer.showCount();
	}

}
