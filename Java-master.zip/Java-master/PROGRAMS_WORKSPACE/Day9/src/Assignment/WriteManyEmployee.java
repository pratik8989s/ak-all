package Assignment;

import java.util.Scanner;

public class WriteManyEmployee {

	public static void main(String[] args) {
		
		System.out.println("how many emp u want to enter:");
		Scanner sc = null;
		int n=sc.nextInt();
		Employee e[]=new Employee[n];
		
		
	}
}
