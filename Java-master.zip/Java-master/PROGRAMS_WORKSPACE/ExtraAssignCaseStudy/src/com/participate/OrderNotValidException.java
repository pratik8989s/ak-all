package com.participate;

public class OrderNotValidException extends Exception {

	public OrderNotValidException(String message) {
		super(message);
		
	}
	
}
