package InterfaceDemo;

public class Clinic 
{

	public static void main(String[] args) 
	{
		Doctor d=new Doctor();
		d.getData();
		d.putData();

	}

}
