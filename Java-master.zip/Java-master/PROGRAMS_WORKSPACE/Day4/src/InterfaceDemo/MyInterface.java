package InterfaceDemo;

public interface MyInterface 
{
	public void getData();
	public void putData();
}
