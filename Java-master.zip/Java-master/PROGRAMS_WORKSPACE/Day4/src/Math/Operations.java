package Math;
import java.lang.Math;
public interface Operations {

void max();
void sq();
void rou();

}
